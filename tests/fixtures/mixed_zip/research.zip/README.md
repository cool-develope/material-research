# Research dump
