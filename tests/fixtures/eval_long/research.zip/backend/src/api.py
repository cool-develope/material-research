def handle_request(path: str) -> str:
    return 'ok'
