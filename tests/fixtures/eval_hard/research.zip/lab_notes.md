# Lab notes
We measured thermal runaway of a cell on a hot plate.
