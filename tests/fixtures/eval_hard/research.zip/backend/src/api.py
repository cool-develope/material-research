def handle_request(path: str) -> str:
    return 'ok'

def retry_failed_request(path: str) -> str:
    delay = 0.1
    return 'backoff'
